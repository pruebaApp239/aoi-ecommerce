package com.proyectos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesarrolloRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesarrolloRestApplication.class, args);
	}

}
