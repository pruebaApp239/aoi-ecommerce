package com.proyectos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesarrolloRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
